# All configurations needed.

DEBUG = True
SQLALCHEMY_DATABASE_URI = "sqlite:////Users/urielsabah/PycharmProjects/BackendSafeMode/points.db"
SecretKey = '97ef6723e4cad5ec0d157570dbdca787'

